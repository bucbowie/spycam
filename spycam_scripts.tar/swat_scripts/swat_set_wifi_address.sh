#!/bin/bash
# name: swat_set_wifi_address.sh
# desc: Assign STATIC IP to wireless or wlan0 IP
# usage: ./swat_set_wifi_address.sh
#
 export MY_SCRIPT="swat_set_wifi_address.sh"
 export SCRIPT_DIR=/home/swat/swat_scripts
 [[ -f "${SCRIPT_DIR}"/swat.config ]] && { . "${SCRIPT_DIR}"/swat.config; }
 [[ (  -z "${MY_EMAIL_MAIL_HUB}" ) || (  -z "${MY_EMAIL_ADDRESS}" ) || (  -z "${MY_EMAIL_PW}" ) ]] && { exit 0; }
 export MY_CONFIG_WIFI_IP="${MY_SERVER_WIFI_IP}"
 [[ ! -z "${MY_CONFIG_WIFI_IP}" ]] &&  { exit 0; }

  export MY_NEW_WIFI_ADDRESS=`${SCRIPT_DIR}/swat_get_wifi_address.sh`
  [[ -z "${MY_NEW_WIFI_ADDRESS}" ]] && { exit 0; }
  
 sudo sed -i.bak '/MY_SERVER_WIFI_IP/s/MY_SERVER_WIFI_IP=\"\"/MY_SERVER_WIFI_IP=\"'"${MY_NEW_WIFI_ADDRESS}"'\"/' /boot/swat.config
 myRC=$?
 [[ ${myRC} -ne 0 ]] && { exit 0; }

 myCNT=`cat /etc/dhcpcd.conf|grep -v ^\#|grep wlan0|wc -l` 
 [[ ${myCNT} -ne 0 ]] && { exit 0; }

 sudo cp /etc/dhcpcd.conf /etc/dhcpcd.conf.pristine

 echo " interface ${WIFI_DEVICE}" >> /etc/dhcpcd.conf
 echo " static ip_address=${MY_NEW_WIFI_ADDRESS}/24" >> /etc/dhcpcd.conf
 echo " static routers=${MY_ROUTER_IP}" >> /etc/dhcpcd.conf 
 echo " static domain_name_servers=${MY_ROUTER_IP}" >> /etc/dhcpcd.conf 
 echo " static domain_name_servers=8.8.8.8" >> /etc/dhcpcd.conf 
 echo " static domain_name_servers=8.8.4.4" >> /etc/dhcpcd.conf 

 echo -e "From: `hostname`\nNOTE:Camera will be active after NEXT REBOOT."|sudo mail -s "Cam web address: ${MY_NEW_WIFI_ADDRESS}/cam/"  "${MY_EMAIL_ADDRESS}" >/dev/null 2>&1
